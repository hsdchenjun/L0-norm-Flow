
close all;
clear;


show_flow =1; % 1 = display the evolution of the flow, 0 = do not show
h = figure('Name', 'Optical flow');

I1 = double(imread('data/Army_frame10.png'))/255;
I2 = double(imread('data/Army_frame11.png'))/255;

%Illuminated Image Sequences

%I1 = double(imread('data/RubberWhale_frame10.png'))/255;
%I2 = double(imread('data/RubberWhale_frame11.png'))/255;
%I1 = double(imread('data/RubberWhale_illumination_10.png'))/255;
%I2 = double(imread('data/RubberWhale_illumination_11.png'))/255;

%I1 = double(imread('data/Grove3_frame10.png'))/255;
%I2 = double(imread('data/Grove3_frame11.png'))/255;
%I1 = double(imread('data/Grove3_illumination_10.png'))/255;
%I2 = double(imread('data/Grove3_illumination_11.png'))/255;

% parameter settings
 pt = parameter_settings();

 pt.lambda = 0.08;% the weight to control the number of non-zero flow graidents
 pt.alpha = 0.05; % the weight of the regularization term
 pt.pyramid_factor = 0.5; % rescalling settings
 pt.warps = 5; % the numbers of warps per level
 pt.max_its = 10; % the number of equation iterations per warp
 
[flow] = coarse_to_fine(I1, I2, pt, show_flow, h);

u = flow(:, :, 1);
v = flow(:, :, 2);

flowImg = uint8(robust_flowToColor(flow));
figure; imshow(flowImg);



